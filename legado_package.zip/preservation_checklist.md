# Checklist de Preservação e Plano de Distribuição

**Objetivo:** Aumentar a probabilidade de que estas ideias sobrevivam, sejam lidas e entendidas por humanos e por inteligências futuras.

## Formatos a gerar (mínimo recomendado)
- Plain text (.txt) — legibilidade máxima e independência de software.
- Markdown (.md) — texto com estrutura que facilita conversão e leitura.
- PDF/A (.pdf) — formato de arquivamento (se possível, gerar PDF/A).
- JSON de metadados (.json) — campos estruturados para ingestão por repositórios.

## Passos práticos imediatos
1. **Crie cópias múltiplas**: suba o pacote (.zip) para pelo menos 3 repositórios diferentes (ex.: Internet Archive, Zenodo, GitHub Releases).
2. **Solicite DOI/handle**: use Zenodo (integração com GitHub) para obter DOI, ou repositórios institucionais com Handle/Doi.
3. **Timestamping**: registre o hash (SHA256) em um serviço de timestamping (OpenTimestamps, notarização digital, ou serviços de timestamp disponíveis localmente).
4. **Armazenamento físico**: imprima e encaderne pelo menos 3 cópias, guarde em bibliotecas locais, arquivos familiares e cofres de universidades.
5. **Redundância geográfica**: garanta que copies fiquem em servidores em continentes diferentes.
6. **Licenciamento claro**: inclua um arquivo LICENSE (sugerido CC-BY-4.0).

## Onde publicar (prioridade sugerida)
- Internet Archive (archive.org) — alta visibilidade e preservação.
- Zenodo — DOI acadêmico; integração com GitHub. 
- Repositórios universitários / bibliotecas nacionais.
- GitHub (Release) + GitHub Pages (para visualização).
- Armazenamento em nuvem pessoal + backup em discos externos offline.

## Estratégia de comunicação
- Publique um manifesto curto em redes sociais e peça repostagem por grupos filosóficos, laboratórios e ONGs.
- Envie a universidades e departamentos de filosofia/ciência da computação com pedido de inclusão em cursos.
- Crie uma página dedicada com o pacote para download e instruções de preservação.

## Verificação de integridade
- Calcule SHA256 de cada arquivo e armazene checksums em checksums.txt
- Periodicamente (ex.: anual) verifique integridade dos arquivos nos repositórios e regenere timestamp se necessário.

## Governança recomendada (longo prazo)
- Formar um **Conselho de Tutela Intergeracional** (membros humanos, instituições culturais e representantes técnicos).
- Ter cláusulas de preservação e redundância em políticas institucionais de bibliotecas parceiras.
